import React from "react";

import img1 from 'assets/images/users/1.jpg';
import img2 from 'assets/images/users/2.jpg';
import img3 from 'assets/images/users/3.jpg';
import img4 from 'assets/images/users/4.jpg';

import {
	Card,
	CardBody,
	CardTitle,
	CardSubtitle,
	Input,
	Table,
	Col,
	Form,
	FormGroup
} from 'reactstrap';

class Pendingtestprojects extends React.Component {
	constructor(props) {
		super(props);

		this.toggle10 = this.toggle10.bind(this);
		this.toggle20 = this.toggle20.bind(this);
		this.toggle30 = this.toggle30.bind(this);
		this.toggle40 = this.toggle40.bind(this);
		this.state = {
			tooltipOpen10: false,
			tooltipOpen20: false,
			tooltipOpen30: false,
			tooltipOpen40: false
		};
	}

	toggle10() {
		this.setState({
			tooltipOpen10: !this.state.tooltipOpen10
		});
	}

	toggle20() {
		this.setState({
			tooltipOpen20: !this.state.tooltipOpen20
		});
	}

	toggle30() {
		this.setState({
			tooltipOpen30: !this.state.tooltipOpen30
		});
	}

	toggle40() {
		this.setState({
			tooltipOpen40: !this.state.tooltipOpen40
		});
	}

	render() {
		return (
			/*--------------------------------------------------------------------------------*/
			/* Used In Dashboard-4 [General]                                                  */
			/*--------------------------------------------------------------------------------*/

			<Card>
				<CardBody>
					<div className="d-flex align-items-center">
						<div>
							<CardTitle>Sample Receipts of the Month</CardTitle>
							<CardSubtitle>Overview of Latest Month</CardSubtitle>
						</div>
						<div className="ml-auto d-flex no-block align-items-center">
							<div className="dl">
								<Form>
									<FormGroup row>
										<Col sm={10}>
											<Input type="text" className="custom-search" placeholder="search" />
										</Col>
									</FormGroup>
								</Form>
							</div>
						</div>
					</div>	
					<Form>
						<Table className="no-wrap v-middle" responsive>
							<thead>
								<tr className="border-0">
									<th className="border-0">
										<FormGroup>
											<Input type="radio" name="radioname" />
										</FormGroup>
									</th>
									<th className="border-0">Sample Id</th>
									<th className="border-0">Delivery Time</th>
									<th className="border-0">Report Comments</th>
									<th className="border-0">Report upload</th>
									<th className="border-0">Sample Status</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>
										<FormGroup>
											<Input type="radio" name="radioname" checked="checked" />
										</FormGroup>
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<div className="">
												<h5 className="mb-0 font-16 font-medium">XYSSX123445</h5>
												<h6 className="mb-0 font-14 font-medium text-secondary mt-2">Milk Package-1</h6>
											</div>
										</div>
									</td>
									<td>05/09/2019 05:15 pm</td>
									<td>
										<FormGroup>
											<Input type="textarea" name="text" id="exampleText" placeholder="remarks" rows="1"/>
										</FormGroup>
									</td>
									<td>
										<i className="ti-upload"></i>									
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<FormGroup>
												<Input type="select" name="selectMulti" id="exampleSelectMulti">
													<option>select status</option>
													<option>2</option>
													<option>3</option>
													<option>4</option>
													<option>5</option>
												</Input>
											</FormGroup>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<FormGroup>
											<Input type="radio" name="radioname" checked="checked" />
										</FormGroup>
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<div className="">
												<h5 className="mb-0 font-16 font-medium">XYSSX123445</h5>
												<h6 className="mb-0 font-14 font-medium text-secondary mt-2">Milk Package-1</h6>
											</div>
										</div>
									</td>
									<td>05/09/2019 05:15 pm</td>
									<td>
										<FormGroup>
											<Input type="textarea" name="text" id="exampleText" placeholder="remarks" rows="1"/>
										</FormGroup>
									</td>
									<td>
										<i className="ti-upload"></i>									
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<FormGroup>
												<Input type="select" name="selectMulti" id="exampleSelectMulti">
													<option>select status</option>
													<option>2</option>
													<option>3</option>
													<option>4</option>
													<option>5</option>
												</Input>
											</FormGroup>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<FormGroup>
											<Input type="radio" name="radioname" checked="checked" />
										</FormGroup>
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<div className="">
												<h5 className="mb-0 font-16 font-medium">XYSSX123445</h5>
												<h6 className="mb-0 font-14 font-medium text-secondary mt-2">Milk Package-1</h6>
											</div>
										</div>
									</td>
									<td>05/09/2019 05:15 pm</td>
									<td>
										<FormGroup>
											<Input type="textarea" name="text" id="exampleText" placeholder="remarks" rows="1"/>
										</FormGroup>
									</td>
									<td>
										<i className="ti-upload"></i>									
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<FormGroup>
												<Input type="select" name="selectMulti" id="exampleSelectMulti">
													<option>select status</option>
													<option>2</option>
													<option>3</option>
													<option>4</option>
													<option>5</option>
												</Input>
											</FormGroup>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<FormGroup>
											<Input type="radio" name="radioname" checked="checked" />
										</FormGroup>
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<div className="">
												<h5 className="mb-0 font-16 font-medium">XYSSX123445</h5>
												<h6 className="mb-0 font-14 font-medium text-secondary mt-2">Milk Package-1</h6>
											</div>
										</div>
									</td>
									<td>05/09/2019 05:15 pm</td>
									<td>
										<FormGroup>
											<Input type="textarea" name="text" id="exampleText" placeholder="remarks" rows="1"/>
										</FormGroup>
									</td>
									<td>
										<i className="ti-upload"></i>									
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<FormGroup>
												<Input type="select" name="selectMulti" id="exampleSelectMulti">
													<option>select status</option>
													<option>2</option>
													<option>3</option>
													<option>4</option>
													<option>5</option>
												</Input>
											</FormGroup>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<FormGroup>
											<Input type="radio" name="radioname" checked="checked" />
										</FormGroup>
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<div className="">
												<h5 className="mb-0 font-16 font-medium">XYSSX123445</h5>
												<h6 className="mb-0 font-14 font-medium text-secondary mt-2">Milk Package-1</h6>
											</div>
										</div>
									</td>
									<td>05/09/2019 05:15 pm</td>
									<td>
										<FormGroup>
											<Input type="textarea" name="text" id="exampleText" placeholder="remarks" rows="1"/>
										</FormGroup>
									</td>
									<td>
										<i className="ti-upload"></i>									
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<FormGroup>
												<Input type="select" name="selectMulti" id="exampleSelectMulti">
													<option>select status</option>
													<option>2</option>
													<option>3</option>
													<option>4</option>
													<option>5</option>
												</Input>
											</FormGroup>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<FormGroup>
											<Input type="radio" name="radioname" checked="checked" />
										</FormGroup>
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<div className="">
												<h5 className="mb-0 font-16 font-medium">XYSSX123445</h5>
												<h6 className="mb-0 font-14 font-medium text-secondary mt-2">Milk Package-1</h6>
											</div>
										</div>
									</td>
									<td>05/09/2019 05:15 pm</td>
									<td>
										<FormGroup>
											<Input type="textarea" name="text" id="exampleText" placeholder="remarks" rows="1"/>
										</FormGroup>
									</td>
									<td>
										<i className="ti-upload"></i>									
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<FormGroup>
												<Input type="select" name="selectMulti" id="exampleSelectMulti">
													<option>select status</option>
													<option>2</option>
													<option>3</option>
													<option>4</option>
													<option>5</option>
												</Input>
											</FormGroup>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<FormGroup>
											<Input type="radio" name="radioname" checked="checked" />
										</FormGroup>
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<div className="">
												<h5 className="mb-0 font-16 font-medium">XYSSX123445</h5>
												<h6 className="mb-0 font-14 font-medium text-secondary mt-2">Milk Package-1</h6>
											</div>
										</div>
									</td>
									<td>05/09/2019 05:15 pm</td>
									<td>
										<FormGroup>
											<Input type="textarea" name="text" id="exampleText" placeholder="remarks" rows="1"/>
										</FormGroup>
									</td>
									<td>
										<i className="ti-upload"></i>									
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<FormGroup>
												<Input type="select" name="selectMulti" id="exampleSelectMulti">
													<option>select status</option>
													<option>2</option>
													<option>3</option>
													<option>4</option>
													<option>5</option>
												</Input>
											</FormGroup>
										</div>
									</td>
								</tr>
							</tbody>
						</Table>
					</Form>
				</CardBody>
			</Card>
		);
	}
}

export default Pendingtestprojects;
