import React from "react";

import img1 from 'assets/images/users/1.jpg';
import img2 from 'assets/images/users/2.jpg';
import img3 from 'assets/images/users/3.jpg';
import img4 from 'assets/images/users/4.jpg';

import {
	Card,
	CardBody,
	CardTitle,
	CardSubtitle,
	Input,
	Table,
	Col,
	Form,
	FormGroup
} from 'reactstrap';

class Historyprojects extends React.Component {
	constructor(props) {
		super(props);

		this.toggle10 = this.toggle10.bind(this);
		this.toggle20 = this.toggle20.bind(this);
		this.toggle30 = this.toggle30.bind(this);
		this.toggle40 = this.toggle40.bind(this);
		this.state = {
			tooltipOpen10: false,
			tooltipOpen20: false,
			tooltipOpen30: false,
			tooltipOpen40: false
		};
	}

	toggle10() {
		this.setState({
			tooltipOpen10: !this.state.tooltipOpen10
		});
	}

	toggle20() {
		this.setState({
			tooltipOpen20: !this.state.tooltipOpen20
		});
	}

	toggle30() {
		this.setState({
			tooltipOpen30: !this.state.tooltipOpen30
		});
	}

	toggle40() {
		this.setState({
			tooltipOpen40: !this.state.tooltipOpen40
		});
	}

	render() {
		return (
			/*--------------------------------------------------------------------------------*/
			/* Used In Dashboard-4 [General]                                                  */
			/*--------------------------------------------------------------------------------*/

			<Card>
				<CardBody>
					<div className="d-flex align-items-center">
						<div>
							<CardTitle>Sample Receipts of the Month</CardTitle>
							<CardSubtitle>Overview of Latest Month</CardSubtitle>
						</div>
						<div className="ml-auto d-flex no-block align-items-center">
							<div className="dl">
								<Form>
									<FormGroup row>
										<Col sm={10}>
											<Input type="text" className="custom-search" placeholder="search" />
										</Col>
									</FormGroup>
								</Form>
							</div>
						</div>
					</div>
					<Form>
						<Table className="no-wrap v-middle" responsive>
							<thead>
								<tr className="border-0">
									<th className="border-0">
										<FormGroup>
											<Input type="checkbox" name="checkbox" />
										</FormGroup>
									</th>
									<th className="border-0">Sample Id</th>
									<th className="border-0">Sample Name</th>

									<th className="border-0">Test Description</th>
									<th className="border-0">Report number</th>
									<th className="border-0">Report PDF</th>
									<th className="border-0">In Time</th>
									<th className="border-0">Test Time</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>
										<FormGroup>
											<Input type="checkbox" name="checkbox" checked="checked" />
										</FormGroup>
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<div className="">
												<h5 className="mb-0 font-16 font-medium">XYSSX123445</h5>
											</div>
										</div>
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<div className="">
												<h5 className="mb-0 font-16 font-medium">Milk Package-1</h5>
											</div>
										</div>
									</td>
									<td>
										<div className="d-flex no-block align-items-center">									
											<FormGroup>
												<Input type="text" name="name" placeholder="ex: Poor Quality" />
											</FormGroup>
										</div>
									</td>
									<td>
										<FormGroup>
											<Input type="text" name="name" placeholder="ex: sampl1254" />
										</FormGroup>
									</td>
									<td>
									<i className="ti-download"></i>									
									</td>
									<td>05/09/2019</td>
									<td>05:15 pm</td>
								</tr>
								<tr>
									<td>
										<FormGroup>
											<Input type="checkbox" name="checkbox" />
										</FormGroup>
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<div className="">
												<h5 className="mb-0 font-16 font-medium">XYSSX123445</h5>
											</div>
										</div>
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<div className="">
												<h5 className="mb-0 font-16 font-medium">Milk Package-1</h5>
											</div>
										</div>
									</td>
									<td>
										<div className="d-flex no-block align-items-center">									
											<FormGroup>
												<Input type="text" name="name" placeholder="ex: Poor Quality" />
											</FormGroup>
										</div>
									</td>
									<td>
										<FormGroup>
											<Input type="text" name="name" placeholder="ex: sampl1254" />
										</FormGroup>
									</td>
									<td>
									<i className="ti-download"></i>									
									</td>
									<td>05/09/2019</td>
									<td>05:15 pm</td>
								</tr>
								<tr>
									<td>
										<FormGroup>
											<Input type="checkbox" name="checkbox" />
										</FormGroup>
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<div className="">
												<h5 className="mb-0 font-16 font-medium">XYSSX123445</h5>
											</div>
										</div>
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<div className="">
												<h5 className="mb-0 font-16 font-medium">Milk Package-1</h5>
											</div>
										</div>
									</td>
									<td>
										<div className="d-flex no-block align-items-center">									
											<FormGroup>
												<Input type="text" name="name" placeholder="ex: Poor Quality" />
											</FormGroup>
										</div>
									</td>
									<td>
										<FormGroup>
											<Input type="text" name="name" placeholder="ex: sampl1254" />
										</FormGroup>
									</td>
									<td>
									<i className="ti-download"></i>									
									</td>
									<td>05/09/2019</td>
									<td>05:15 pm</td>
								</tr>
								<tr>
									<td>
										<FormGroup>
											<Input type="checkbox" name="checkbox" />
										</FormGroup>
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<div className="">
												<h5 className="mb-0 font-16 font-medium">XYSSX123445</h5>
											</div>
										</div>
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<div className="">
												<h5 className="mb-0 font-16 font-medium">Milk Package-1</h5>
											</div>
										</div>
									</td>
									<td>
										<div className="d-flex no-block align-items-center">									
											<FormGroup>
												<Input type="text" name="name" placeholder="ex: Poor Quality" />
											</FormGroup>
										</div>
									</td>
									<td>
										<FormGroup>
											<Input type="text" name="name" placeholder="ex: sampl1254" />
										</FormGroup>
									</td>
									<td>
									<i className="ti-download"></i>									
									</td>
									<td>05/09/2019</td>
									<td>05:15 pm</td>
								</tr>
								<tr>
									<td>
										<FormGroup>
											<Input type="checkbox" name="checkbox" />
										</FormGroup>
									</td>									
									<td>
										<div className="d-flex no-block align-items-center">
											<div className="">
												<h5 className="mb-0 font-16 font-medium">XYSSX123445</h5>
											</div>
										</div>
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<div className="">
												<h5 className="mb-0 font-16 font-medium">Milk Package-1</h5>
											</div>
										</div>
									</td>
									<td>
										<div className="d-flex no-block align-items-center">									
											<FormGroup>
												<Input type="text" name="name" placeholder="ex: Poor Quality" />
											</FormGroup>
										</div>
									</td>
									<td>
										<FormGroup>
											<Input type="text" name="name" placeholder="ex: sampl1254" />
										</FormGroup>
									</td>
									<td>
									<i className="ti-download"></i>									
									</td>
									<td>05/09/2019</td>
									<td>05:15 pm</td>
								</tr>
								<tr>
									<td>
										<FormGroup>
											<Input type="checkbox" name="checkbox" />
										</FormGroup>
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<div className="">
												<h5 className="mb-0 font-16 font-medium">XYSSX123445</h5>
											</div>
										</div>
									</td>
									<td>
										<div className="d-flex no-block align-items-center">
											<div className="">
												<h5 className="mb-0 font-16 font-medium">Milk Package-1</h5>
											</div>
										</div>
									</td>
									<td>
										<div className="d-flex no-block align-items-center">									
											<FormGroup>
												<Input type="text" name="name" placeholder="ex: Poor Quality" />
											</FormGroup>
										</div>
									</td>
									<td>
										<FormGroup>
											<Input type="text" name="name" placeholder="ex: sampl1254" />
										</FormGroup>
									</td>
									<td>
									<i className="ti-download"></i>									
									</td>
									<td>05/09/2019</td>
									<td>05:15 pm</td>
								</tr>
							</tbody>
						</Table>
					</Form>
				</CardBody>
			</Card>
		);
	}
}

export default Historyprojects;
