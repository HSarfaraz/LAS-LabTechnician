import React from 'react';
import {
    Pagination, 
    PaginationItem, 
    PaginationLink, 
    Row,
    Col,
    label
} from 'reactstrap';
//import { Historyprojects } from 'components/dashboard-components';
import Historyprojects from '../components/dashboard-components/historyprojects/historyprojects';

class History extends React.Component {
    render() {
        return (
            <div>
                <Row>
                    <Col sm={12}>
                        <Historyprojects />
                    </Col>
                </Row>
                <Row>
                    <Col sm="12" md={{ size: 8, offset: 5 }}>
                      <Pagination aria-label="Page navigation example">
                            <label className="mr-1 font-weight-bold">Pages from 1-6 out 50</label>
                            <PaginationItem>
                              <PaginationLink previous href="#"> <i className="ti-angle-left mr-1 ml-1" /></PaginationLink>
                            </PaginationItem>
                            <PaginationItem>
                              <PaginationLink next href="#" > <i className="ti-angle-right mr-1 ml-1" /></PaginationLink>
                            </PaginationItem>
                          </Pagination>
                    </Col>
                </Row>                 
            </div>
        );

    }
}

export default History;
